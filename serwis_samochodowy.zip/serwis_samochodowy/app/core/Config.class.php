<?php


class Config {
    public static $db = [
        'host' => 'localhost',
        'database' => 'serwis_samochodowy',
        'user' => 'root',
        'password' => '',
        'charset' => 'utf8mb4'
    ];
}
