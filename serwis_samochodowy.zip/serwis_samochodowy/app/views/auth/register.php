<form action="/serwis_samochodowy/public/index.php?action=register" method="POST">
    Login: <input type="text" name="login"><br>
    Hasło: <input type="password" name="password"><br>
    Imię: <input type="text" name="name"><br>
    Nazwisko: <input type="text" name="surname"><br>
    E-mail: <input type="email" name="email"><br>
    Telefon: <input type="text" name="phone"><br>
    <input type="submit" value="Zarejestruj się">
</form>