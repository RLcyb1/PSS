
# Stronnicowanie w projekcie "serwis_samochodowy"

Stronnicowanie znajduje się w następujących miejscach:

### Kontroler:
- `app/controllers/AdminCtrl.class.php`  
(logika pobierania danych z uwzględnieniem LIMIT i OFFSET)

### Widok:
- `app/views/admin/users.php`  
(interfejs użytkownika z nawigacją pomiędzy stronami danych)

### Routing:
- `public/index.php`  
(switch sterujący akcjami aplikacji)
