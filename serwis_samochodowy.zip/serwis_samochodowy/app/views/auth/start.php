
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Witamy</title>
</head>
<body>
    <h2>Witamy w serwisie samochodowym</h2>
    <p>Wybierz, co chcesz zrobić:</p>
    <a href="index.php?action=login">Zaloguj się</a> |
    <a href="index.php?action=register">Zarejestruj się</a>
</body>
</html>
