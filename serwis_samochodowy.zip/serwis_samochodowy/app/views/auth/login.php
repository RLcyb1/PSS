<form action="/serwis_samochodowy/public/index.php?action=login" method="POST">

  Login: <input type="text" name="login" required><br>
  Hasło: <input type="password" name="password" required><br>
  <button>Zaloguj się</button>
</form>